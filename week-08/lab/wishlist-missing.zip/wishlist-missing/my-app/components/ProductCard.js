import Link from "next/link";

// TODO (Jotai): import what you need to read and update the wishlist atom (from "@/store").

export default function ProductCard({ product }) {
  // TODO (Jotai): read AND update the wishlist atom here (you need both the
  //   value and its setter).

  function addToWishlist() {
    // TODO (Jotai): add this product to the wishlist without mutating the old
    //   array, then remove the console.log below.
    console.log("TODO: add to wishlist", product.title);
  }

  return (
    <div
      style={{
        border: "1px solid #ccc",
        borderRadius: "6px",
        padding: "10px",
        margin: "10px",
        width: "220px",
      }}
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={product.thumbnail} alt={product.title} width="100%" />
      <h3>
        <Link href={`/products/${product.id}`}>{product.title}</Link>
      </h3>
      <p>
        {product.category} &middot; ${product.price}
      </p>
      <p>Rating: {product.rating} / 5</p>
      <button onClick={addToWishlist}>Add to Wishlist</button>
    </div>
  );
}
