import Link from "next/link";

// TODO (Part 2): import "useAtom" from "jotai" and "wishlistAtom" from "@/store"

export default function ProductCard({ product }) {
  // TODO (Part 2): const [wishlist, setWishlist] = useAtom(wishlistAtom);

  function addToWishlist() {
    console.log("TODO: add to wishlist", product.title);
  }

  return (
    <div
      style={{
        border: "1px solid #ccc",
        borderRadius: "6px",
        padding: "10px",
        margin: "10px",
        width: "220px",
      }}
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={product.thumbnail} alt={product.title} width="100%" />
      <h3>
        <Link href={`/products/${product.id}`}>{product.title}</Link>
      </h3>
      <p>
        {product.category} &middot; ${product.price}
      </p>
      <p>Rating: {product.rating} / 5</p>
      <button onClick={addToWishlist}>Add to Wishlist</button>
    </div>
  );
}
