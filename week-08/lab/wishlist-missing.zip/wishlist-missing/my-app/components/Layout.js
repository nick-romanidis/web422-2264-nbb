import Link from "next/link";

// TODO (Context): import what you need to read the user from Context (from "@/pages/_app").
// TODO (Jotai): import what you need to read the wishlist atom (from "@/store").

export default function Layout(props) {
  // TODO (Context): read the current user so you can show who is logged in.
  // TODO (Jotai): read the wishlist so you can show its item count in the navbar.

  return (
    <div style={{ padding: "10px" }}>
      <h2>Gadget Wishlist</h2>
      <nav>
        <Link href="/">Home</Link> | <Link href="/products">Products</Link> |{" "}
        <Link href="/wishlist">
          {/* TODO (Jotai): replace the hard-coded 0 with the live item count. */}
          Wishlist <span>(0)</span>
        </Link>{" "}
        |{" "}
        {/* TODO (Context): when logged in, show "Logged in as: <name>" instead of
            this Login link. */}
        <Link href="/profile">Login</Link>
      </nav>
      <hr />
      {props.children}
    </div>
  );
}
