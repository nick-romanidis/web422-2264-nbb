import Link from "next/link";

// TODO (Part 2): import "useAtom" from "jotai" and "wishlistAtom" from "@/store"
// TODO (Part 1): import "useContext" from "react" and "UserContext" from "@/pages/_app"

export default function Layout(props) {
  // TODO (Part 2): const [wishlist] = useAtom(wishlistAtom);
  // TODO (Part 1): const user = useContext(UserContext);

  return (
    <div style={{ padding: "10px" }}>
      <h2>Gadget Wishlist</h2>
      <nav>
        <Link href="/">Home</Link> | <Link href="/products">Products</Link> |{" "}
        <Link href="/wishlist">
          Wishlist <span>(0)</span>
        </Link>{" "}
        | <Link href="/profile">Login</Link>
      </nav>
      <hr />
      {props.children}
    </div>
  );
}
