import { useState } from "react";

// TODO (Context): import what you need to read the current user AND update it
//   from Context (both Context objects live in "@/pages/_app"). You will also
//   want a way to redirect to "/" after logging in.

export default function Profile() {
  // TODO (Context): read both the current user and its setter from Context.
  const [name, setName] = useState("");

  function handleLogin(e) {
    e.preventDefault();
    if (!name) return;
    // TODO (Context): log the user in (update the Context), then redirect home.
    console.log("TODO: set the current user via Context ->", name);
  }

  // TODO (Context): when a user is logged in, show "Logged in as: <name>" and a
  //   Logout button here instead of the login form below.

  return (
    <div>
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <label>
          Name:{" "}
          <input value={name} onChange={(e) => setName(e.target.value)} />
        </label>{" "}
        <button type="submit">Login</button>
      </form>
    </div>
  );
}
