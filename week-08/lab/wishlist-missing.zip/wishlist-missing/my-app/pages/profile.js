import { useState } from "react";

// TODO (Part 1): import "useContext" from "react" and "UserContext" /
//   "SetUserContext" from "@/pages/_app". Also import "useRouter" from
//   "next/router" if you want to redirect to "/" after logging in.

export default function Profile() {
  // TODO (Part 1): const user = useContext(UserContext);
  // TODO (Part 1): const setUser = useContext(SetUserContext);
  const [name, setName] = useState("");

  function handleLogin(e) {
    e.preventDefault();
    if (!name) return;
    console.log("TODO: set the current user via Context ->", name);
  }

  return (
    <div>
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <label>
          Name:{" "}
          <input value={name} onChange={(e) => setName(e.target.value)} />
        </label>{" "}
        <button type="submit">Login</button>
      </form>
    </div>
  );
}
