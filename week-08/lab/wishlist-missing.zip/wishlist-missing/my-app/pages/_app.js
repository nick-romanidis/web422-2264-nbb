import "@/styles/globals.css";
import Layout from "@/components/Layout";

// TODO (Part 1): create and export "UserContext" and "SetUserContext" here
//   using createContext(), then wrap <Layout>...</Layout> below with the
//   matching Provider components (with a "user" state declared via useState).

export default function App({ Component, pageProps }) {
  return (
    <Layout>
      <Component {...pageProps} />
    </Layout>
  );
}
