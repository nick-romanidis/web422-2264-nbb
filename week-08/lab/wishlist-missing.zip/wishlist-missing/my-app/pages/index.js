export default function Home() {
  return (
    <div>
      <h2>Welcome to the Gadget Wishlist</h2>
      <p>
        Browse the <strong>Products</strong> page and add your favorites to
        your <strong>Wishlist</strong>. Log in from the <strong>Login</strong>{" "}
        link to have your name shown in the navigation bar.
      </p>
    </div>
  );
}
