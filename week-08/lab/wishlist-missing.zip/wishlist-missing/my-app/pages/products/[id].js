export default function ProductDetail({ product }) {
  // TODO (Jotai): read AND update the wishlist atom here (value + setter), the
  //   same way you did in ProductCard.

  function addToWishlist() {
    // TODO (Jotai): add this product to the wishlist without mutating the old
    //   array, then remove the console.log below.
    console.log("TODO: add to wishlist", product.title);
  }

  return (
    <div>
      <h2>{product.title}</h2>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={product.thumbnail} alt={product.title} width="300" />
      <p>{product.description}</p>
      <p>Category: {product.category}</p>
      <p>Brand: {product.brand || "N/A"}</p>
      <p>Price: ${product.price}</p>
      <p>Rating: {product.rating} / 5</p>
      <button onClick={addToWishlist}>Add to Wishlist</button>
    </div>
  );
}

export async function getStaticPaths() {
  const res = await fetch("https://dummyjson.com/products?limit=12&select=id");
  const data = await res.json();

  const paths = data.products.map((product) => ({
    params: { id: product.id.toString() },
  }));

  return { paths, fallback: false };
}

export async function getStaticProps({ params }) {
  const res = await fetch(`https://dummyjson.com/products/${params.id}`);
  const product = await res.json();

  return { props: { product } };
}
