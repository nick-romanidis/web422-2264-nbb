export default function WishlistPage() {
  // TODO (Part 2): read the wishlist atom and render its items + total price
  //   const [wishlist] = useAtom(wishlistAtom);

  return (
    <div>
      <h2>My Wishlist</h2>
      <p>TODO: show the saved wishlist items and a running total here.</p>
    </div>
  );
}
