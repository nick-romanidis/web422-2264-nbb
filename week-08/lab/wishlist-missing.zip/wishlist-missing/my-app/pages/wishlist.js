export default function WishlistPage() {
  // TODO (Jotai): read the wishlist atom, then render each saved item and a
  //   running total price below.

  return (
    <div>
      <h2>My Wishlist</h2>
      <p>TODO: show the saved wishlist items and a running total here.</p>
    </div>
  );
}
