# Gadget Wishlist &mdash; Starter

This is the **starter** for the Week 8 lab. Follow the walkthrough in
**`week-08-lab.md`** to complete it.

## What works

- The app runs and the **Products** page renders a grid of products fetched
  from the [DummyJSON](https://dummyjson.com/docs/products) API.
- Each product's detail page (`/products/[id]`) also renders correctly.

## What is missing

- The **Wishlist** count in the nav always shows `(0)` and the
  "Add to Wishlist" buttons only log a `TODO` to the console.
- The **Wishlist** page (`/wishlist`) is a placeholder.
- **Login** does nothing &mdash; the current user is never tracked or shown.
- Look for `TODO (Part 1)` and `TODO (Part 2)` comments to see exactly where
  you need to add code.

## Run it

```
npm install
npm run dev
```

Then browse <http://localhost:3000>.

A finished reference is available in the **`wishlist-complete`** folder.
