# Recipe Box &mdash; Completed Reference

This is the **finished** version of the Recipe Box demo &mdash; the answer key for
the `recipe-state-missing` starter. It shows two ways of managing application
level state in a Next.js (Pages Router) app:

- **Context** (`context/UserContext.js`) tracks the current **user**.
- **Jotai** (`store.js`) tracks the **Recipe Box** (the list of saved recipes).

## Run it

```
npm install
npm run dev
```

Then browse <http://localhost:3000>.

## Where the state lives

| Concern | Tool | Files |
| --- | --- | --- |
| Current user | React Context | `context/UserContext.js`, `pages/_app.js`, `components/Layout.js`, `pages/profile.js` |
| Recipe Box list | Jotai atom | `store.js`, `components/Layout.js`, `components/RecipeBox.js`, `pages/recipes/[id].js`, `pages/recipe-box.js` |

Data is pulled from the free [DummyJSON](https://dummyjson.com/docs/recipes)
recipes API.
