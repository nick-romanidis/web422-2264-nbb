import { createContext, useContext, useState } from "react";

// Create the Context that will hold the "current user" for the whole app.
const UserContext = createContext();

// The Provider component wraps the app (see pages/_app.js) and stores the user
// in state so any component below it can read or update the user.
export function UserProvider({ children }) {
  const [user, setUser] = useState(null); // null = nobody is logged in yet

  return (
    <UserContext.Provider value={{ user, setUser }}>
      {children}
    </UserContext.Provider>
  );
}

// A small helper hook so components can grab the user with one line:
//   const { user, setUser } = useUser();
export function useUser() {
  return useContext(UserContext);
}
