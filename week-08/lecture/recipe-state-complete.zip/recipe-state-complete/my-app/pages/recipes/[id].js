import Link from "next/link";
import { useAtom } from "jotai";
import { recipeBoxAtom } from "@/store";

export default function RecipeDetail({ recipe }) {
  const [recipeBox, setRecipeBox] = useAtom(recipeBoxAtom);

  function addToBox(recipe) {
    setRecipeBox([...recipeBox, recipe]);
  }

  return (
    <div>
      <img src={recipe.image} alt={recipe.name} width="200" />
      <h2>{recipe.name}</h2>
      <p>Cuisine: {recipe.cuisine}</p>
      <p>Difficulty: {recipe.difficulty}</p>
      <p>
        Rating: {recipe.rating} ({recipe.reviewCount} reviews)
      </p>
      <p>
        Prep: {recipe.prepTimeMinutes} min &middot; Cook:{" "}
        {recipe.cookTimeMinutes} min &middot; Servings: {recipe.servings}
      </p>

      <h3>Ingredients</h3>
      <ul>
        {recipe.ingredients.map((ingredient, index) => (
          <li key={index}>{ingredient}</li>
        ))}
      </ul>

      <h3>Instructions</h3>
      <ol>
        {recipe.instructions.map((step, index) => (
          <li key={index}>{step}</li>
        ))}
      </ol>

      <button onClick={() => addToBox(recipe)}>Add to Box</button>
      <br />
      <br />
      <Link href="/recipes">Back to Recipes</Link>
    </div>
  );
}

// Pre-render a page for each recipe available from DummyJSON.
export async function getStaticPaths() {
  const res = await fetch("https://dummyjson.com/recipes");
  const data = await res.json();

  const paths = data.recipes.map((recipe) => ({
    params: { id: String(recipe.id) },
  }));

  return { paths, fallback: false };
}

export async function getStaticProps({ params }) {
  const res = await fetch(`https://dummyjson.com/recipes/${params.id}`);
  const recipe = await res.json();

  return {
    props: { recipe },
  };
}
