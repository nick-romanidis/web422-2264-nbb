import RecipeBox from "@/components/RecipeBox";

export default function Recipes({ recipes }) {
  return (
    <>
      <h2>Recipes</h2>
      <div style={{ display: "flex", flexWrap: "wrap" }}>
        {recipes.map((recipe) => (
          <RecipeBox key={recipe.id} recipe={recipe} />
        ))}
      </div>
    </>
  );
}

// Pre-render this page at build time with the full list of recipes from DummyJSON.
export async function getStaticProps() {
  const res = await fetch("https://dummyjson.com/recipes");
  const data = await res.json();

  return {
    props: { recipes: data.recipes },
  };
}
