import { useState } from "react";
import { useRouter } from "next/router";
import { useUser } from "@/context/UserContext";

export default function Profile() {
  const { user, setUser } = useUser();
  const [name, setName] = useState("");
  const router = useRouter();

  function handleLogin(e) {
    e.preventDefault();
    if (!name) return;
    setUser({ name }); // update the Context for the whole app
    router.push("/");
  }

  function handleLogout() {
    setUser(null);
  }

  if (user) {
    return (
      <div>
        <h2>Profile</h2>
        <p>Logged in as: {user.name}</p>
        <button onClick={handleLogout}>Logout</button>
      </div>
    );
  }

  return (
    <div>
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <label>
          Name:{" "}
          <input value={name} onChange={(e) => setName(e.target.value)} />
        </label>{" "}
        <button type="submit">Login</button>
      </form>
    </div>
  );
}
