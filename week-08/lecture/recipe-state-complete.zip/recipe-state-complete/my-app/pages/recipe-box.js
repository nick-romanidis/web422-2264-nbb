import { useAtom } from "jotai";
import { recipeBoxAtom } from "@/store";

export default function RecipeBoxPage() {
  const [recipeBox] = useAtom(recipeBoxAtom);

  // Total time = sum of prep + cook time for every recipe in the box.
  const totalTime = recipeBox.reduce(
    (total, recipe) => total + recipe.prepTimeMinutes + recipe.cookTimeMinutes,
    0
  );

  return (
    <>
      <h2>My Recipe Box</h2>
      <ul>
        {recipeBox.map((recipe, index) => (
          <li key={index}>
            <strong>{recipe.name}</strong> &mdash; {recipe.cuisine},{" "}
            {recipe.difficulty}
            <br />
            Prep: {recipe.prepTimeMinutes} min &middot; Cook:{" "}
            {recipe.cookTimeMinutes} min
            <br />
            <br />
          </li>
        ))}
      </ul>
      <hr />
      <strong>Total time: {totalTime} min</strong>
    </>
  );
}
