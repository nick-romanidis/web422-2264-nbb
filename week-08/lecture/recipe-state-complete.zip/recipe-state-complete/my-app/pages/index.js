import Link from "next/link";

export default function Home() {
  return (
    <div>
      <h3>Welcome to the Recipe Box demo</h3>
      <p>
        This sample demonstrates two ways of managing &quot;application
        level&quot; state in a Next.js app:
      </p>
      <ul>
        <li>
          <strong>Context</strong> &ndash; tracks the current <em>user</em> (see
          the Login link in the navbar above and the <code>/profile</code> page).
        </li>
        <li>
          <strong>Jotai</strong> &ndash; tracks the <em>Recipe Box</em>: the list
          of recipes the user has saved (see the count in the navbar and the{" "}
          <code>/recipe-box</code> page).
        </li>
      </ul>
      <p>
        Browse the <Link href="/recipes">Recipes</Link> to get started.
      </p>
    </div>
  );
}
