import Link from "next/link";
import { useAtom } from "jotai";
import { recipeBoxAtom } from "@/store";
import { useUser } from "@/context/UserContext";

export default function Layout(props) {
  // Jotai: read the shared Recipe Box so we can show how many items are in it.
  const [recipeBox] = useAtom(recipeBoxAtom);

  // Context: read the current user.
  const { user } = useUser();

  return (
    <div style={{ padding: "10px" }}>
      <h2>Recipe Box App</h2>
      <nav>
        <Link href="/">Home</Link> | <Link href="/recipes">Recipes</Link> |{" "}
        <Link href="/recipe-box">
          Recipe Box <span>({recipeBox.length})</span>
        </Link>{" "}
        |{" "}
        {user ? (
          <span>Logged in as: {user.name}</span>
        ) : (
          <Link href="/profile">Login</Link>
        )}
      </nav>
      <hr />
      {props.children}
    </div>
  );
}
