import Link from "next/link";
import { useAtom } from "jotai";
import { recipeBoxAtom } from "@/store";

export default function RecipeBox({ recipe }) {
  const [recipeBox, setRecipeBox] = useAtom(recipeBoxAtom);

  function addToBox(recipe) {
    // Spread the existing list, then append the new recipe.
    setRecipeBox([...recipeBox, recipe]);
  }

  return (
    <div
      style={{
        maxWidth: "300px",
        border: "1px solid #ccc",
        borderRadius: "8px",
        margin: "10px",
        padding: "10px",
      }}
    >
      {/* A plain <img> keeps the sample config-free (no next/image domains). */}
      <img src={recipe.image} alt={recipe.name} width="100%" />
      <h3>{recipe.name}</h3>
      <p>
        {recipe.cuisine} &middot; {recipe.difficulty}
      </p>
      <p>
        Prep: {recipe.prepTimeMinutes} min &middot; Cook:{" "}
        {recipe.cookTimeMinutes} min
      </p>
      <Link href={`/recipes/${recipe.id}`}>Details</Link>{" "}
      <button onClick={() => addToBox(recipe)}>Add to Box</button>
    </div>
  );
}
