import { atom } from "jotai";

// Application-level state: the list of recipes the user has saved to their box.
// Starts empty; components add to it with setRecipeBox([...recipeBox, recipe]).
export const recipeBoxAtom = atom([]);
