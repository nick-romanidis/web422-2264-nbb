# Week 11 Lab — Testing (`my-app`, starter)

The **starter** for the Week 11 testing lab. This is the Vehicles UI app with
Jest and Cypress **already installed and configured** — your job is to write the
tests. Follow **`week-11/lab/week-11-lab.md`**.

The test files already exist in `tests/` and `cypress/e2e/`, but each one is a
**stub**: a `describe` block with `// TODO` comments telling you what to assert.
`test.todo(...)` (Jest) and `it("name")` with no body (Cypress) mark work that
isn't done yet.

## Install & run the app

```bash
npm install
npm run dev          # http://localhost:3000  — log in with bob / myPassword
```

## Run the tests as you write them

```bash
npm run test         # Jest, watch mode

# Cypress (needs `npm run dev` running in another terminal):
npm run cypress          # interactive runner
npm run cypress:headless # terminal only
```

Stuck? Revisit the **Week 11 lecture walkthrough** &mdash; it solves the same
kinds of tests on different files. Find the closest example, understand *why* it
works, then apply the idea to your task.
