import Login from "@/pages/login";
import { render } from "@testing-library/react";

// The Login page calls useRouter(), which does not exist in a plain unit test,
// so rendering it would throw. This replaces the "next/router" module with a
// fake whose useRouter() returns just the push() the component uses. Leave this
// here — the lab explains it. (Try commenting it out to see the error!)
jest.mock("next/router", () => ({
  useRouter: () => ({ push: jest.fn() }),
}));

describe("Login Page", () => {
  // TODO 1.4a: render <Login /> and assert the page contains:
  //   - an input with name="username"   -> container.querySelector('input[name="username"]')
  //   - an input with name="password"
  //   - a button with type="submit"     -> container.querySelector('button[type="submit"]')
  //   Each of those should be truthy (they exist).
  test.todo("renders a username field, a password field, and a submit button");

  // TODO 1.4b (stretch): assert the password input's "type" attribute is "password".
  //   Hint: element.getAttribute("type")
  test.todo("renders the password field as a password input");
});
