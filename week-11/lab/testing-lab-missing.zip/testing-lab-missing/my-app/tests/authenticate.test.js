import {
  setToken,
  getToken,
  removeToken,
  isAuthenticated,
} from "@/lib/authenticate";

describe("authenticate token helpers", () => {
  // Hint: localStorage is shared between tests in jsdom, so clear it first:
  //   beforeEach(() => {
  //     localStorage.clear();
  //   });

  // TODO 1.3a: after setToken("abc.123"), getToken() should return "abc.123".
  test.todo("setToken stores a token that getToken reads back");

  // TODO 1.3b: isAuthenticated() should be false before any token is set,
  //   and true after setToken(...).
  test.todo("isAuthenticated reflects whether a token is stored");

  // TODO 1.3c: after removeToken(), getToken() should return null.
  test.todo("removeToken clears the stored token");
});
