import { createMocks } from "node-mocks-http";
import handler from "@/pages/api/login";

describe("/api/login Route", () => {
  // TODO 1.2a: a POST with the correct credentials should respond 200 and the
  //   JSON body should contain a token.
  //   - createMocks({ method: "POST", body: { userName: "bob", password: "myPassword" } })
  //   - assert res._getStatusCode() is 200
  //   - assert the parsed body contains a token, e.g.:
  //       expect(JSON.parse(res._getData())).toEqual(
  //         expect.objectContaining({ token: expect.any(String) })
  //       );
  test.todo("returns 200 and a token for valid credentials");

  // TODO 1.2b: a POST with a wrong password should respond 422.
  test.todo("returns 422 for an invalid password");

  // TODO 1.2c (stretch): a GET request should respond 405.
  test.todo("returns 405 for a GET request");
});
