import { createMocks } from "node-mocks-http";
import handler from "@/pages/api/vehicles/index";

describe("/api/vehicles Route (list)", () => {
  // TODO 1.1a: a GET request should respond 200 and return all 3 vehicles.
  //   - build a mock request:   const { req, res } = createMocks({ method: "GET" });
  //   - run the handler:        await handler(req, res);
  //   - assert the status code is 200      -> res._getStatusCode()
  //   - parse the body and assert it is an array of length 3
  //       const data = JSON.parse(res._getData());
  //   Replace this test.todo with a real test(...) once you write it.
  test.todo("returns all vehicles on GET");

  // TODO 1.1b: an unsupported method (e.g. "POST") should respond 405.
  test.todo("returns 405 for an unsupported method");
});
