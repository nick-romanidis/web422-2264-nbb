describe("logging in reveals the vehicles", () => {
  // TODO 2.2: drive a real login and confirm the protected page appears.
  //   - cy.visit("/login")
  //   - type into the inputs (they have name="username" / name="password"):
  //       cy.get('input[name="username"]').type("bob")
  //       cy.get('input[name="password"]').type("myPassword{enter}")   // {enter} submits
  //   - assert the URL includes "/vehicles"      -> cy.url().should("include", "/vehicles")
  //   - assert the page contains "Chrysler"      -> cy.contains("Chrysler")
  //   - assert the nav contains "Logout"         -> cy.get("nav").contains("Logout")
  it("logs in as bob and shows a vehicle plus a Logout link");

  // TODO 2.2b (stretch): after logging in, click Logout in the nav and assert
  //   the URL returns to "/login".
  it("logs back out again");
});
