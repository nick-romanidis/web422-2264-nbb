describe("home page click counter", () => {
  // TODO 2.1: the counter on the Home page ("/") should go up when clicked.
  //   - cy.visit("/")
  //   - find the button that says "Clicked 0 Times" and click it:
  //       cy.contains("button", "Clicked 0 Times").click();
  //   - assert the button now says "Clicked 1 Times"
  //   Replace this pending `it` (it has no test body yet) with a real one.
  it("increments the counter each time the button is clicked");
});
